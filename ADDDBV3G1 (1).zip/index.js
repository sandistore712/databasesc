const fs = require("fs");
const axios = require("axios");
const TelegramBot = require("node-telegram-bot-api");
const { v4: uuidv4 } = require("uuid");

const BOT_TOKEN = "8376712525:AAEQ8RQV8cJOXESucQ2VWZ9rsocNiNVLZm8";
const bot = new TelegramBot(BOT_TOKEN, { polling: true });

const GITHUB_USER = "yandek123";
const GITHUB_REPO = "ZILL";
const GITHUB_PATH = "tokens.json";
const GITHUB_PAT = "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";
const GITHUB_API_URL = `https://api.github.com/repos/${GITHUB_USER}/${GITHUB_REPO}/contents/${GITHUB_PATH}`;

const MENU_VIDEO = "https://files.catbox.moe/z44wd7.mp4";
const START_AUDIO = "https://files.catbox.moe/v2pgcn.mp3";

const ADMIN_FILE = "./admin.json";
const RESELLER_FILE = "./resellers.json";

function loadAdmins() {
  if (!fs.existsSync(ADMIN_FILE)) return { owners: [], admins: [] };
  return JSON.parse(fs.readFileSync(ADMIN_FILE));
}
function loadResellers() {
  if (!fs.existsSync(RESELLER_FILE)) return { resellers: [] };
  return JSON.parse(fs.readFileSync(RESELLER_FILE));
}
function saveAdmins(adminData) {
  fs.writeFileSync(ADMIN_FILE, JSON.stringify(adminData, null, 2));
}
function saveResellers(resellerData) {
  fs.writeFileSync(RESELLER_FILE, JSON.stringify(resellerData, null, 2));
}

function isOwner(userId) {
  return loadAdmins().owners.includes(userId);
}
function isAdmin(userId) {
  const { admins, owners } = loadAdmins();
  return owners.includes(userId) || admins.includes(userId);
}
function isReseller(userId) {
  return loadResellers().resellers.includes(userId);
}
function hasAccess(userId) {
  return isOwner(userId) || isAdmin(userId) || isReseller(userId);
}

async function fetchTokens() {
  try {
    const res = await axios.get(
      `https://raw.githubusercontent.com/${GITHUB_USER}/${GITHUB_REPO}/main/${GITHUB_PATH}`,
      { headers: { "Cache-Control": "no-cache" } }
    );
    return res.data.tokens || [];
  } catch {
    return [];
  }
}

async function updateTokens(tokens) {
  try {
    const { data } = await axios.get(GITHUB_API_URL, {
      headers: { Authorization: `token ${GITHUB_PAT}` },
    });
    const sha = data.sha;
    const updatedContent = Buffer.from(
      JSON.stringify({ tokens }, null, 2)
    ).toString("base64");
    await axios.put(
      GITHUB_API_URL,
      { message: "Update token list", content: updatedContent, sha },
      { headers: { Authorization: `token ${GITHUB_PAT}` } }
    );
    return true;
  } catch (err) {
    console.error("Update token GitHub error:", err.message);
    return false;
  }
}

async function sendMainMenu(chatId, userId) {
  const caption = `<blockquote>TRICKSTER VERSION 3 Database</blockquote>
<blockquote>Simple Add</blockquote>
/adduser - ID

/addtoken
/listtoken
/deltoken
<blockquote>Select The Button🤭.</blockquote>`;

  const keyboard = { inline_keyboard: [] };

  if (isOwner(userId)) {
    keyboard.inline_keyboard.push(
      [{ text: "Tambah Token", callback_data: "add_token" }],
      [{ text: "Tambah User", callback_data: "add_user" }]
    );
  } else if (isAdmin(userId)) {
    keyboard.inline_keyboard.push(
      [{ text: "Tambah Token", callback_data: "add_token" }],
      [{ text: "Tambah User", callback_data: "add_user" }]
    );
  } else if (isReseller(userId)) {
    keyboard.inline_keyboard.push(
      [{ text: "Tambah Token", callback_data: "add_token" }]
    );
  }

  await bot.sendVideo(chatId, MENU_VIDEO, {
    caption,
    reply_markup: keyboard,
    parse_mode: "HTML",
  });
}

bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!hasAccess(userId))
    return bot.sendMessage(chatId, "❌ Anda tidak memiliki akses!");

  sendMainMenu(chatId, userId);

  bot.sendAudio(chatId, START_AUDIO, {
    caption: `
<blockquote>Quoted By @Ziilxynotdev</blockquote>
<blockquote>⭓ ɪs ʜᴇʀᴇ</blockquote>
<blockquote>━━━━𝙯𝙞𝙡𝙡𝙭𝙮𝙣𝙤𝙩𝙙𝙚𝙫 𝗠𝗼𝗱𝗲 𝗦𝗮𝗱</blockquote>
<blockquote>Created By @Ziilxynotdev</blockquote>
`,
    parse_mode: "HTML",
  });
});

let pendingTokens = [];
let pendingUsers = {};

bot.onText(/\/addtoken (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const newToken = match[1].trim();

  if (!hasAccess(userId))
    return bot.sendMessage(chatId, "❌ Anda tidak memiliki akses!");

  const censorToken = (token) =>
    token.length <= 8 ? "****" : token.slice(0, 4) + "...." + token.slice(-4);
  const censoredToken = censorToken(newToken);

  const tokenId = uuidv4();
  pendingTokens.push({ id: tokenId, token: newToken, userId });

  const caption = `<blockquote>Requested By: @${
    msg.from.username || msg.from.first_name
  }</blockquote>
<blockquote>Konfirmasi Di Bawah Ini!</blockquote>
╭━━━━⭓ Tambah Token 
┃➺ Token: ${censoredToken} 
┃➺ Pilih Jenis Token 
╰━━━━━━━━━━━━━━━━━━⭓
<blockquote>Created By @Ziilxynotdev</blockquote>`;

  const keyboard = {
    inline_keyboard: [
      [
        { text: "Token Pribadi", callback_data: `approve_private|${tokenId}` },
        { text: "Token Buyer", callback_data: `approve_buyer|${tokenId}` },
      ],
    ],
  };

  bot.sendMessage(chatId, caption, { reply_markup: keyboard, parse_mode: "HTML" });
});

bot.on("callback_query", async (callbackQuery) => {
  const data = callbackQuery.data;
  const chatId = callbackQuery.message.chat.id;
  const fromId = callbackQuery.from.id;

  if (data === "mainmenu") return sendMainMenu(chatId, fromId);

  if (data === "add_user") {
    return bot.sendMessage(chatId, "Ketik /adduser <id> untuk menambahkan user!");
  }

  if (data.startsWith("setrole|")) {
    const [_, role, userId] = data.split("|");

    if (role === "owner" && !isOwner(fromId)) {
      return bot.answerCallbackQuery(callbackQuery.id, {
        text: "❌ Hanya Owner yang bisa menambahkan Owner!",
        show_alert: true,
      });
    }
    if (role === "partner" && !isOwner(fromId)) {
      return bot.answerCallbackQuery(callbackQuery.id, {
        text: "❌ Hanya Owner yang bisa menambahkan Partner!",
        show_alert: true,
      });
    }
    if (role === "reseller" && !(isOwner(fromId) || isAdmin(fromId))) {
      return bot.answerCallbackQuery(callbackQuery.id, {
        text: "❌ Hanya Owner/Admin yang bisa menambahkan Reseller!",
        show_alert: true,
      });
    }

    const uid = parseInt(userId);
    if (role === "owner") {
      const admins = loadAdmins();
      if (!admins.owners.includes(uid)) admins.owners.push(uid);
      saveAdmins(admins);
    } else if (role === "partner") {
      const admins = loadAdmins();
      if (!admins.admins.includes(uid)) admins.admins.push(uid);
      saveAdmins(admins);
    } else if (role === "reseller") {
      const resellers = loadResellers();
      if (!resellers.resellers.includes(uid)) resellers.resellers.push(uid);
      saveResellers(resellers);
    }

    return bot.editMessageText(
      `✅ User ${uid} berhasil ditambahkan sebagai ${role}!`,
      { chat_id: chatId, message_id: callbackQuery.message.message_id }
    );
  }

  // === APPROVE TOKEN ===
  const [action, tokenId] = data.split("|");
  const pending = pendingTokens.find((t) => t.id === tokenId);
  if (!pending) return;

  // hanya owner boleh approve
  if (!isOwner(fromId)) {
    return bot.answerCallbackQuery(callbackQuery.id, {
      text: "❌ Yaps Anda Tolol",
      show_alert: true,
    });
  }

  let tokens = await fetchTokens();
  if (tokens.includes(pending.token)) {
    return bot.sendMessage(chatId, "⚠️ Token sudah ada di GitHub!");
  }

  tokens.push(pending.token);
  const success = await updateTokens(tokens);
  if (!success) return bot.sendMessage(chatId, "❌ Gagal menambahkan token ke GitHub!");

  pendingTokens = pendingTokens.filter((t) => t.id !== tokenId);

  await bot.editMessageText(
    "✅ Token berhasil ditambahkan ke database!",
    { chat_id: chatId, message_id: callbackQuery.message.message_id }
  );
});

bot.onText(/\/deltoken (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const tokenToRemove = match[1].trim();

  if (!hasAccess(msg.from.id)) return bot.sendMessage(chatId, "❌ Anda tidak memiliki akses!");

  try {
    let tokens = await fetchTokens();
    if (!tokens.includes(tokenToRemove))
      return bot.sendMessage(chatId, `⚠️ Token "${tokenToRemove}" tidak ditemukan!`);

    tokens = tokens.filter((t) => t !== tokenToRemove);
    const success = await updateTokens(tokens);
    bot.sendMessage(chatId, success ? `✅ Token "${tokenToRemove}" dihapus!` : `❌ Gagal menghapus token "${tokenToRemove}"!`);
  } catch (error) {
    console.error("Error deleting token:", error);
    bot.sendMessage(chatId, `❌ Terjadi kesalahan: ${error.message}`);
  }
});

bot.onText(/\/listtoken/, async (msg) => {
  const chatId = msg.chat.id;
  if (!hasAccess(msg.from.id)) return bot.sendMessage(chatId, "❌ Anda tidak memiliki akses!");

  const tokens = await fetchTokens();
  if (!tokens || tokens.length === 0) return bot.sendMessage(chatId, "⚠️ Tidak ada token tersimpan.");

  const tokenList = tokens.map((t) =>
    t.length <= 6 ? "****" : `${t.slice(0, 3)}***${t.slice(-3)}`
  ).join("\n");

  bot.sendMessage(chatId, `📜 **Daftar Token:**\n\`\`\`${tokenList}\`\`\``, { parse_mode: "Markdown" });
});

bot.onText(/\/adduser (\d+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const newId = match[1];

  if (!hasAccess(msg.from.id)) {
    return bot.sendMessage(chatId, "❌ Anda tidak memiliki akses!");
  }

  const keyboard = {
    inline_keyboard: [
      [{ text: "Tambahkan Reseller", callback_data: `setrole|reseller|${newId}` }],
      [{ text: "Tambahkan Partner", callback_data: `setrole|partner|${newId}` }],
      [{ text: "Tambahkan Owner", callback_data: `setrole|owner|${newId}` }]
    ]
  };

  bot.sendMessage(chatId, `Pilih role untuk user ${newId}:`, { reply_markup: keyboard });
});

bot.on("polling_error", (err) => console.error("Polling error:", err.code, err.response?.body || err.message));
process.on("unhandledRejection", (reason) => console.error("Unhandled Rejection:", reason));
process.on("uncaughtException", (err) => console.error("Uncaught Exception:", err));

console.log("🚀 Bot Token Manager berjalan...");